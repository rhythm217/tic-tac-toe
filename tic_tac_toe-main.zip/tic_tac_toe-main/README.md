# Build a production app in Flutter. Tic Tac Toe game - Flutter tutorial

In this tutorial you will learn how to create the famous Tic Tac Toe game.

![Build a production app - Flutter tutorial](tic_tac_toe.png)

Link to my tutorial tutorial
- [Blog tutorial](https://davideagostini.com/build-a-production-app-in-flutter-tic-tac-toe-game) - Build a production app in Flutter. Tic Tac Toe game.

Subscribe to my channel to see more videos
- [YouTube channel](https://www.youtube.com/c/davideagostini)